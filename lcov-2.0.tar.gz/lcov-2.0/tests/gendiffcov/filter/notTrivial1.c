void skipMe(unsigned, unsigned) { return 1; }
